# Programa principal de repl.it: todos los programas se ejecutan como
# función de este progama,
# Referir de la siguiente manera:
# from nombreprogramasinextensiónpy import nombrefunciónprincipaldelprograma
# nombrefunciónprincipaldelprograma()   -> Le llamaremos main()

from HolaMundo import main
main()
#Este archivo es muy importante ya que hay que modificar la palabra para ejecutar codigos"