# holamundo es un mensaje basico.

# El punto de entrada se llamará main
# Se compone de un estatuto def que significa que lo definiremos

def main():
    print("Hola mundo, ahora estas en el archivo de Edgar Carrera en Python")