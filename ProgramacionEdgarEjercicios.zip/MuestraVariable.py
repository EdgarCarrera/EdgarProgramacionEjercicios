# Aqui declaramos una variable .

def main():
  # Y lo hacemos mediante la asignacion como se ve en la siguiente linea.
  txt="Hola mundo, por declaración de variable"
  print(txt)